package com.dependent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
