package com.dependent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DependentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DependentServiceApplication.class, args);
	}

}
